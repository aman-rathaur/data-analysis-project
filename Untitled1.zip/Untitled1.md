```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

```


```python
import pandas as pd

df = pd.read_csv(r"C:\Users\DELL\Downloads\BlinkIT Grocery Data.xlsx - BlinkIT Grocery Data.csv")
print(df)
```

         Item Fat Content Item Identifier              Item Type  \
    0             Regular           FDX32  Fruits and Vegetables   
    1             Low Fat           NCB42     Health and Hygiene   
    2             Regular           FDR28           Frozen Foods   
    3             Regular           FDL50                 Canned   
    4             Low Fat           DRI25            Soft Drinks   
    ...               ...             ...                    ...   
    8518          low fat           NCT53     Health and Hygiene   
    8519          low fat           FDN09            Snack Foods   
    8520          low fat           DRE13            Soft Drinks   
    8521              reg           FDT50                  Dairy   
    8522              reg           FDM58            Snack Foods   
    
          Outlet Establishment Year Outlet Identifier Outlet Location Type  \
    0                          2012            OUT049               Tier 1   
    1                          2022            OUT018               Tier 3   
    2                          2016            OUT046               Tier 1   
    3                          2014            OUT013               Tier 3   
    4                          2015            OUT045               Tier 2   
    ...                         ...               ...                  ...   
    8518                       2018            OUT027               Tier 3   
    8519                       2018            OUT027               Tier 3   
    8520                       2018            OUT027               Tier 3   
    8521                       2018            OUT027               Tier 3   
    8522                       2018            OUT027               Tier 3   
    
         Outlet Size        Outlet Type  Item Visibility  Item Weight     Sales  \
    0         Medium  Supermarket Type1         0.100014        15.10  145.4786   
    1         Medium  Supermarket Type2         0.008596        11.80  115.3492   
    2          Small  Supermarket Type1         0.025896        13.85  165.0210   
    3           High  Supermarket Type1         0.042278        12.15  126.5046   
    4          Small  Supermarket Type1         0.033970        19.60   55.1614   
    ...          ...                ...              ...          ...       ...   
    8518      Medium  Supermarket Type3         0.000000          NaN  164.5526   
    8519      Medium  Supermarket Type3         0.034706          NaN  241.6828   
    8520      Medium  Supermarket Type3         0.027571          NaN   86.6198   
    8521      Medium  Supermarket Type3         0.107715          NaN   97.8752   
    8522      Medium  Supermarket Type3         0.000000          NaN  112.2544   
    
          Rating  
    0        5.0  
    1        5.0  
    2        5.0  
    3        5.0  
    4        5.0  
    ...      ...  
    8518     4.0  
    8519     4.0  
    8520     4.0  
    8521     4.0  
    8522     4.0  
    
    [8523 rows x 12 columns]
    


```python
df.head(4000)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Item Fat Content</th>
      <th>Item Identifier</th>
      <th>Item Type</th>
      <th>Outlet Establishment Year</th>
      <th>Outlet Identifier</th>
      <th>Outlet Location Type</th>
      <th>Outlet Size</th>
      <th>Outlet Type</th>
      <th>Item Visibility</th>
      <th>Item Weight</th>
      <th>Sales</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Regular</td>
      <td>FDX32</td>
      <td>Fruits and Vegetables</td>
      <td>2012</td>
      <td>OUT049</td>
      <td>Tier 1</td>
      <td>Medium</td>
      <td>Supermarket Type1</td>
      <td>0.100014</td>
      <td>15.10</td>
      <td>145.4786</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Low Fat</td>
      <td>NCB42</td>
      <td>Health and Hygiene</td>
      <td>2022</td>
      <td>OUT018</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type2</td>
      <td>0.008596</td>
      <td>11.80</td>
      <td>115.3492</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Regular</td>
      <td>FDR28</td>
      <td>Frozen Foods</td>
      <td>2016</td>
      <td>OUT046</td>
      <td>Tier 1</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.025896</td>
      <td>13.85</td>
      <td>165.0210</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Regular</td>
      <td>FDL50</td>
      <td>Canned</td>
      <td>2014</td>
      <td>OUT013</td>
      <td>Tier 3</td>
      <td>High</td>
      <td>Supermarket Type1</td>
      <td>0.042278</td>
      <td>12.15</td>
      <td>126.5046</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Low Fat</td>
      <td>DRI25</td>
      <td>Soft Drinks</td>
      <td>2015</td>
      <td>OUT045</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.033970</td>
      <td>19.60</td>
      <td>55.1614</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3995</th>
      <td>Regular</td>
      <td>FDX57</td>
      <td>Snack Foods</td>
      <td>2020</td>
      <td>OUT017</td>
      <td>Tier 2</td>
      <td>Medium</td>
      <td>Supermarket Type1</td>
      <td>0.047534</td>
      <td>17.25</td>
      <td>96.9068</td>
      <td>3.9</td>
    </tr>
    <tr>
      <th>3996</th>
      <td>Regular</td>
      <td>DRC36</td>
      <td>Soft Drinks</td>
      <td>2020</td>
      <td>OUT017</td>
      <td>Tier 2</td>
      <td>Medium</td>
      <td>Supermarket Type1</td>
      <td>0.045239</td>
      <td>13.00</td>
      <td>174.1054</td>
      <td>3.9</td>
    </tr>
    <tr>
      <th>3997</th>
      <td>low fat</td>
      <td>FDN24</td>
      <td>Baking Goods</td>
      <td>2020</td>
      <td>OUT017</td>
      <td>Tier 2</td>
      <td>Medium</td>
      <td>Supermarket Type1</td>
      <td>0.113908</td>
      <td>14.10</td>
      <td>53.3956</td>
      <td>3.9</td>
    </tr>
    <tr>
      <th>3998</th>
      <td>Low Fat</td>
      <td>FDJ48</td>
      <td>Baking Goods</td>
      <td>2017</td>
      <td>OUT035</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.056424</td>
      <td>11.30</td>
      <td>247.8118</td>
      <td>3.9</td>
    </tr>
    <tr>
      <th>3999</th>
      <td>Low Fat</td>
      <td>FDN48</td>
      <td>Baking Goods</td>
      <td>2017</td>
      <td>OUT035</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.064938</td>
      <td>13.35</td>
      <td>90.0804</td>
      <td>3.9</td>
    </tr>
  </tbody>
</table>
<p>4000 rows × 12 columns</p>
</div>




```python
print(df.isnull().sum())

```

    Item Fat Content             0
    Item Identifier              0
    Item Type                    0
    Outlet Establishment Year    0
    Outlet Identifier            0
    Outlet Location Type         0
    Outlet Size                  0
    Outlet Type                  0
    Item Visibility              0
    Item Weight                  0
    Sales                        0
    Rating                       0
    dtype: int64
    


```python

```


```python

```

         Item Fat Content Item Identifier              Item Type  \
    0             Regular           FDX32  Fruits and Vegetables   
    1             Low Fat           NCB42     Health and Hygiene   
    2             Regular           FDR28           Frozen Foods   
    3             Regular           FDL50                 Canned   
    4             Low Fat           DRI25            Soft Drinks   
    ...               ...             ...                    ...   
    8241              reg           FDH26                 Canned   
    8242              reg           FDG56  Fruits and Vegetables   
    8243              reg           FDM15                   Meat   
    8244              reg           FDX57            Snack Foods   
    8245              reg           FDD10            Snack Foods   
    
          Outlet Establishment Year Outlet Identifier Outlet Location Type  \
    0                          2012            OUT049               Tier 1   
    1                          2022            OUT018               Tier 3   
    2                          2016            OUT046               Tier 1   
    3                          2014            OUT013               Tier 3   
    4                          2015            OUT045               Tier 2   
    ...                         ...               ...                  ...   
    8241                       2022            OUT018               Tier 3   
    8242                       2022            OUT018               Tier 3   
    8243                       2022            OUT018               Tier 3   
    8244                       2022            OUT018               Tier 3   
    8245                       2022            OUT018               Tier 3   
    
         Outlet Size        Outlet Type  Item Visibility  Item Weight     Sales  \
    0         Medium  Supermarket Type1         0.100014        15.10  145.4786   
    1         Medium  Supermarket Type2         0.008596        11.80  115.3492   
    2          Small  Supermarket Type1         0.025896        13.85  165.0210   
    3           High  Supermarket Type1         0.042278        12.15  126.5046   
    4          Small  Supermarket Type1         0.033970        19.60   55.1614   
    ...          ...                ...              ...          ...       ...   
    8241      Medium  Supermarket Type2         0.034841        19.25  141.1496   
    8242      Medium  Supermarket Type2         0.071744        13.30   59.7536   
    8243      Medium  Supermarket Type2         0.057655        11.80  152.6366   
    8244      Medium  Supermarket Type2         0.047459        17.25   95.8068   
    8245      Medium  Supermarket Type2         0.046208        20.60  178.0344   
    
          Rating  
    0        5.0  
    1        5.0  
    2        5.0  
    3        5.0  
    4        5.0  
    ...      ...  
    8241     4.0  
    8242     4.0  
    8243     4.0  
    8244     4.0  
    8245     4.0  
    
    [7060 rows x 12 columns]
    


```python
print(df['Item Fat Content'].unique())
```

    ['Regular' 'Low Fat' 'low fat' 'LF' 'reg']
    


```python
df['Item Fat Content'] = df['Item Fat Content'].replace({
    'LF': 'Low Fat',
    'low fat': 'Low Fat',
    'reg': 'Regular'
})

```


```python
print(df['Item Fat Content'].unique())
```

    ['Regular' 'Low Fat']
    


```python
total_sales = df['Sales'].count()
print(total_sales)

```

    7060
    


```python
import pandas as pd
import plotly.express as px
Sales_by_fat = df.groupby('Item Fat Content')['Sales'].sum().reset_index()

# Pie chart plot करें
fig = px.pie(
    Sales_by_fat,
    names='Item Fat Content',
    values='Sales',
    title='Sales by Fat Content',
    width=600,    # width in pixels
    height=600   # height in pixels
)


fig.update_traces(textposition='inside', textinfo='percent+label')  # Labels और percent दिखाने के लिए
fig.show()

```


<div>                            <div id="41447631-9907-42e1-bcb7-7de6d5dfbf12" class="plotly-graph-div" style="height:600px; width:600px;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("41447631-9907-42e1-bcb7-7de6d5dfbf12")) {                    Plotly.newPlot(                        "41447631-9907-42e1-bcb7-7de6d5dfbf12",                        [{"domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"hovertemplate":"Item Fat Content=%{label}\u003cbr\u003eSales=%{value}\u003cextra\u003e\u003c\u002fextra\u003e","labels":["Low Fat","Regular"],"legendgroup":"","name":"","showlegend":true,"values":[644516.742,352642.4938],"type":"pie","textinfo":"percent+label","textposition":"inside"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"legend":{"tracegroupgap":0},"title":{"text":"Sales by Fat Content"},"height":600,"width":600},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('41447631-9907-42e1-bcb7-7de6d5dfbf12');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
import plotly.express as px

# Group sales by item type
sales_by_type = df.groupby('Item Type')['Sales'].sum().reset_index().sort_values(by='Sales', ascending=False)


# Create bar chart
fig = px.bar(
    sales_by_type,
    x='Item Type',
    y='Sales',
    title='Total Sales by Item Type',
    color='Item Type',
    text='Sales'  # Labels दिखाने के लिए
)

# Labels formatting
fig.update_traces(    texttemplate='%{text:,.0f}',  # 1,000 format में दिखाने के लिए
    textposition='outside'        # Labels बार के बाहर
)

# Layout settings
fig.update_layout(
    uniformtext_minsize=8,
    uniformtext_mode='hide',
    width=1000,   # Chart width in pixels
    height=600    # Chart height in pixels
)

fig.show()

```


<div>                            <div id="46cd2184-9f4d-47d7-8bcc-014c37f7c9ff" class="plotly-graph-div" style="height:600px; width:1000px;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("46cd2184-9f4d-47d7-8bcc-014c37f7c9ff")) {                    Plotly.newPlot(                        "46cd2184-9f4d-47d7-8bcc-014c37f7c9ff",                        [{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Fruits and Vegetables","marker":{"color":"#636efa","pattern":{"shape":""}},"name":"Fruits and Vegetables","offsetgroup":"Fruits and Vegetables","orientation":"v","showlegend":true,"text":[147188.9632],"textposition":"outside","x":["Fruits and Vegetables"],"xaxis":"x","y":[147188.9632],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Snack Foods","marker":{"color":"#EF553B","pattern":{"shape":""}},"name":"Snack Foods","offsetgroup":"Snack Foods","orientation":"v","showlegend":true,"text":[144949.13],"textposition":"outside","x":["Snack Foods"],"xaxis":"x","y":[144949.13],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Household","marker":{"color":"#00cc96","pattern":{"shape":""}},"name":"Household","offsetgroup":"Household","orientation":"v","showlegend":true,"text":[113210.14199999999],"textposition":"outside","x":["Household"],"xaxis":"x","y":[113210.14199999999],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Frozen Foods","marker":{"color":"#ab63fa","pattern":{"shape":""}},"name":"Frozen Foods","offsetgroup":"Frozen Foods","orientation":"v","showlegend":true,"text":[99961.8818],"textposition":"outside","x":["Frozen Foods"],"xaxis":"x","y":[99961.8818],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Dairy","marker":{"color":"#FFA15A","pattern":{"shape":""}},"name":"Dairy","offsetgroup":"Dairy","orientation":"v","showlegend":true,"text":[84526.4968],"textposition":"outside","x":["Dairy"],"xaxis":"x","y":[84526.4968],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Canned","marker":{"color":"#19d3f3","pattern":{"shape":""}},"name":"Canned","offsetgroup":"Canned","orientation":"v","showlegend":true,"text":[75053.0],"textposition":"outside","x":["Canned"],"xaxis":"x","y":[75053.0],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Baking Goods","marker":{"color":"#FF6692","pattern":{"shape":""}},"name":"Baking Goods","offsetgroup":"Baking Goods","orientation":"v","showlegend":true,"text":[67588.113],"textposition":"outside","x":["Baking Goods"],"xaxis":"x","y":[67588.113],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Health and Hygiene","marker":{"color":"#B6E880","pattern":{"shape":""}},"name":"Health and Hygiene","offsetgroup":"Health and Hygiene","orientation":"v","showlegend":true,"text":[56383.802],"textposition":"outside","x":["Health and Hygiene"],"xaxis":"x","y":[56383.802],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Soft Drinks","marker":{"color":"#FF97FF","pattern":{"shape":""}},"name":"Soft Drinks","offsetgroup":"Soft Drinks","orientation":"v","showlegend":true,"text":[49294.6738],"textposition":"outside","x":["Soft Drinks"],"xaxis":"x","y":[49294.6738],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Meat","marker":{"color":"#FECB52","pattern":{"shape":""}},"name":"Meat","offsetgroup":"Meat","orientation":"v","showlegend":true,"text":[47159.901],"textposition":"outside","x":["Meat"],"xaxis":"x","y":[47159.901],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Breads","marker":{"color":"#636efa","pattern":{"shape":""}},"name":"Breads","offsetgroup":"Breads","orientation":"v","showlegend":true,"text":[28663.1848],"textposition":"outside","x":["Breads"],"xaxis":"x","y":[28663.1848],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Hard Drinks","marker":{"color":"#EF553B","pattern":{"shape":""}},"name":"Hard Drinks","offsetgroup":"Hard Drinks","orientation":"v","showlegend":true,"text":[25261.6214],"textposition":"outside","x":["Hard Drinks"],"xaxis":"x","y":[25261.6214],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Starchy Foods","marker":{"color":"#00cc96","pattern":{"shape":""}},"name":"Starchy Foods","offsetgroup":"Starchy Foods","orientation":"v","showlegend":true,"text":[19199.9772],"textposition":"outside","x":["Starchy Foods"],"xaxis":"x","y":[19199.9772],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Others","marker":{"color":"#ab63fa","pattern":{"shape":""}},"name":"Others","offsetgroup":"Others","orientation":"v","showlegend":true,"text":[18624.597],"textposition":"outside","x":["Others"],"xaxis":"x","y":[18624.597],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Breakfast","marker":{"color":"#FFA15A","pattern":{"shape":""}},"name":"Breakfast","offsetgroup":"Breakfast","orientation":"v","showlegend":true,"text":[12696.1874],"textposition":"outside","x":["Breakfast"],"xaxis":"x","y":[12696.1874],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"},{"alignmentgroup":"True","hovertemplate":"Item Type=%{x}\u003cbr\u003eSales=%{text}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Seafood","marker":{"color":"#19d3f3","pattern":{"shape":""}},"name":"Seafood","offsetgroup":"Seafood","orientation":"v","showlegend":true,"text":[7397.5644],"textposition":"outside","x":["Seafood"],"xaxis":"x","y":[7397.5644],"yaxis":"y","type":"bar","texttemplate":"%{text:,.0f}"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"Item Type"},"categoryorder":"array","categoryarray":["Fruits and Vegetables","Snack Foods","Household","Frozen Foods","Dairy","Canned","Baking Goods","Health and Hygiene","Soft Drinks","Meat","Breads","Hard Drinks","Starchy Foods","Others","Breakfast","Seafood"]},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Sales"}},"legend":{"title":{"text":"Item Type"},"tracegroupgap":0},"title":{"text":"Total Sales by Item Type"},"barmode":"relative","uniformtext":{"minsize":8,"mode":"hide"},"width":1000,"height":600},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('46cd2184-9f4d-47d7-8bcc-014c37f7c9ff');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
print(df['Sales'].sum())  # Total sales पूरी data में

```

    997159.2357999999
    


```python
print(df.columns)

```

    Index(['Item Fat Content', 'Item Identifier', 'Item Type',
           'Outlet Establishment Year', 'Outlet Identifier',
           'Outlet Location Type', 'Outlet Size', 'Outlet Type', 'Item Visibility',
           'Item Weight', 'Sales', 'Rating'],
          dtype='object')
    


```python
outlet_Sales_year = df.groupby('Outlet Establishment Year')['Sales'].sum().reset_index()
fig = px.line(outlet_Sales_year , x = 'Outlet Establishment Year',y = 'Sales')
all_years = pd.DataFrame({'Outlet Establishment Year': range(1998, 2019)})
marker = 'O'
fig.show()
```


<div>                            <div id="3b99700a-487c-45bb-b7fc-e3d3a3f32f32" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("3b99700a-487c-45bb-b7fc-e3d3a3f32f32")) {                    Plotly.newPlot(                        "3b99700a-487c-45bb-b7fc-e3d3a3f32f32",                        [{"hovertemplate":"Outlet Establishment Year=%{x}\u003cbr\u003eSales=%{y}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"","line":{"color":"#636efa","dash":"solid"},"marker":{"symbol":"circle"},"mode":"lines","name":"","orientation":"v","showlegend":false,"x":[1998,1999,2000,2001,2002],"xaxis":"x","y":[1000,1500,2000,1700,2100],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"Outlet Establishment Year"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Sales"}},"legend":{"tracegroupgap":0},"margin":{"t":60}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('3b99700a-487c-45bb-b7fc-e3d3a3f32f32');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
import os
print(os.getcwd())

```

    C:\Users\DELL
    


```python

```
